# eating > 2024-09-02 12:14pm
https://universe.roboflow.com/smokingyolo/eating-50gih

Provided by a Roboflow user
License: CC BY 4.0

